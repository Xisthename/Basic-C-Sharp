﻿namespace Ping_Pong
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameForm));
            this.updateTimer = new System.Windows.Forms.Timer(this.components);
            this.scoreLabel1 = new System.Windows.Forms.Label();
            this.ScoreLabel2 = new System.Windows.Forms.Label();
            this.inGameExit = new System.Windows.Forms.Button();
            this.inGameResume = new System.Windows.Forms.Button();
            this.inGameMenu = new System.Windows.Forms.Button();
            this.countdownTimer = new System.Windows.Forms.Timer(this.components);
            this.startButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.ballCollision = new System.Windows.Forms.CheckBox();
            this.header = new System.Windows.Forms.Label();
            this.maxBalls = new System.Windows.Forms.ComboBox();
            this.controlButton = new System.Windows.Forms.Button();
            this.maxScore = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // updateTimer
            // 
            this.updateTimer.Interval = 3;
            this.updateTimer.Tick += new System.EventHandler(this.updateTimer_Tick);
            // 
            // scoreLabel1
            // 
            this.scoreLabel1.AutoSize = true;
            this.scoreLabel1.BackColor = System.Drawing.Color.Transparent;
            this.scoreLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLabel1.ForeColor = System.Drawing.Color.Gray;
            this.scoreLabel1.Location = new System.Drawing.Point(989, 10);
            this.scoreLabel1.Name = "scoreLabel1";
            this.scoreLabel1.Size = new System.Drawing.Size(72, 78);
            this.scoreLabel1.TabIndex = 1;
            this.scoreLabel1.Text = "0";
            this.scoreLabel1.Visible = false;
            // 
            // ScoreLabel2
            // 
            this.ScoreLabel2.AutoSize = true;
            this.ScoreLabel2.BackColor = System.Drawing.Color.Transparent;
            this.ScoreLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScoreLabel2.ForeColor = System.Drawing.Color.Gray;
            this.ScoreLabel2.Location = new System.Drawing.Point(911, 10);
            this.ScoreLabel2.Name = "ScoreLabel2";
            this.ScoreLabel2.Size = new System.Drawing.Size(72, 78);
            this.ScoreLabel2.TabIndex = 0;
            this.ScoreLabel2.Text = "0";
            this.ScoreLabel2.Visible = false;
            // 
            // inGameExit
            // 
            this.inGameExit.BackColor = System.Drawing.Color.Gray;
            this.inGameExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.inGameExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.inGameExit.ForeColor = System.Drawing.Color.White;
            this.inGameExit.Location = new System.Drawing.Point(886, 235);
            this.inGameExit.Name = "inGameExit";
            this.inGameExit.Size = new System.Drawing.Size(200, 50);
            this.inGameExit.TabIndex = 9;
            this.inGameExit.Text = "Exit";
            this.inGameExit.UseVisualStyleBackColor = false;
            this.inGameExit.Visible = false;
            this.inGameExit.Click += new System.EventHandler(this.inGameExit_Click);
            // 
            // inGameResume
            // 
            this.inGameResume.BackColor = System.Drawing.Color.Gray;
            this.inGameResume.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.inGameResume.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inGameResume.ForeColor = System.Drawing.Color.White;
            this.inGameResume.Location = new System.Drawing.Point(886, 91);
            this.inGameResume.Name = "inGameResume";
            this.inGameResume.Size = new System.Drawing.Size(200, 50);
            this.inGameResume.TabIndex = 7;
            this.inGameResume.Text = "Resume";
            this.inGameResume.UseVisualStyleBackColor = false;
            this.inGameResume.Visible = false;
            this.inGameResume.Click += new System.EventHandler(this.inGameResume_Click);
            // 
            // inGameMenu
            // 
            this.inGameMenu.BackColor = System.Drawing.Color.Gray;
            this.inGameMenu.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.inGameMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.inGameMenu.ForeColor = System.Drawing.Color.White;
            this.inGameMenu.Location = new System.Drawing.Point(886, 168);
            this.inGameMenu.Name = "inGameMenu";
            this.inGameMenu.Size = new System.Drawing.Size(200, 50);
            this.inGameMenu.TabIndex = 8;
            this.inGameMenu.Text = "Back To Menu";
            this.inGameMenu.UseVisualStyleBackColor = false;
            this.inGameMenu.Visible = false;
            this.inGameMenu.Click += new System.EventHandler(this.inGameMenu_Click);
            // 
            // countdownTimer
            // 
            this.countdownTimer.Tick += new System.EventHandler(this.countdownTimer_Tick);
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.Color.Gray;
            this.startButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.startButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold);
            this.startButton.ForeColor = System.Drawing.Color.White;
            this.startButton.Location = new System.Drawing.Point(197, 168);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(220, 50);
            this.startButton.TabIndex = 1;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Gray;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold);
            this.exitButton.ForeColor = System.Drawing.Color.White;
            this.exitButton.Location = new System.Drawing.Point(197, 487);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(220, 50);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // ballCollision
            // 
            this.ballCollision.AutoSize = true;
            this.ballCollision.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ballCollision.Location = new System.Drawing.Point(160, 359);
            this.ballCollision.Name = "ballCollision";
            this.ballCollision.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ballCollision.Size = new System.Drawing.Size(311, 36);
            this.ballCollision.TabIndex = 4;
            this.ballCollision.Text = ":Ball collision (Beta)";
            this.ballCollision.UseVisualStyleBackColor = true;
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Font = new System.Drawing.Font("Segoe Script", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.Location = new System.Drawing.Point(60, 21);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(499, 133);
            this.header.TabIndex = 10;
            this.header.Text = "Ping Pong";
            // 
            // maxBalls
            // 
            this.maxBalls.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.maxBalls.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.maxBalls.FormattingEnabled = true;
            this.maxBalls.Location = new System.Drawing.Point(197, 310);
            this.maxBalls.Name = "maxBalls";
            this.maxBalls.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maxBalls.Size = new System.Drawing.Size(220, 33);
            this.maxBalls.TabIndex = 3;
            // 
            // controlButton
            // 
            this.controlButton.BackColor = System.Drawing.Color.Gray;
            this.controlButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.controlButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold);
            this.controlButton.ForeColor = System.Drawing.Color.White;
            this.controlButton.Location = new System.Drawing.Point(197, 415);
            this.controlButton.Name = "controlButton";
            this.controlButton.Size = new System.Drawing.Size(220, 50);
            this.controlButton.TabIndex = 5;
            this.controlButton.Text = "Controls";
            this.controlButton.UseVisualStyleBackColor = false;
            this.controlButton.Click += new System.EventHandler(this.controlButton_Click);
            // 
            // maxScore
            // 
            this.maxScore.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.maxScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.maxScore.FormattingEnabled = true;
            this.maxScore.Location = new System.Drawing.Point(197, 252);
            this.maxScore.Name = "maxScore";
            this.maxScore.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maxScore.Size = new System.Drawing.Size(220, 33);
            this.maxScore.TabIndex = 2;
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1111, 674);
            this.Controls.Add(this.maxScore);
            this.Controls.Add(this.controlButton);
            this.Controls.Add(this.maxBalls);
            this.Controls.Add(this.header);
            this.Controls.Add(this.ballCollision);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.inGameMenu);
            this.Controls.Add(this.inGameResume);
            this.Controls.Add(this.inGameExit);
            this.Controls.Add(this.scoreLabel1);
            this.Controls.Add(this.ScoreLabel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GameForm";
            this.Text = "Ping Pong";
            this.Shown += new System.EventHandler(this.GameForm_Shown);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.GameForm_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GameForm_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.GameForm_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer updateTimer;
        private System.Windows.Forms.Label scoreLabel1;
        private System.Windows.Forms.Label ScoreLabel2;
        private System.Windows.Forms.Button inGameExit;
        private System.Windows.Forms.Button inGameResume;
        private System.Windows.Forms.Button inGameMenu;
        private System.Windows.Forms.Timer countdownTimer;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.CheckBox ballCollision;
        private System.Windows.Forms.Label header;
        private System.Windows.Forms.ComboBox maxBalls;
        private System.Windows.Forms.Button controlButton;
        private System.Windows.Forms.ComboBox maxScore;
    }
}

