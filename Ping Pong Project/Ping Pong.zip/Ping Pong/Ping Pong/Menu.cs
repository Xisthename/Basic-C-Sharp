﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ping_Pong
{
    /// <summary>
    /// Daniel Petersén
    /// 2017-11-30
    /// </summary>
    class Menu
    {
        /// <summary>
        /// Delecering necessary instance variables
        /// </summary>
        private GameForm gameForm;
        private Size screenSize;
        private Label header;
        private Button startButton;
        private ComboBox maxScore;
        private ComboBox maxBalls;
        private CheckBox ballCollision;
        private Button controlButton;
        private Button exitButton;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="gameForm"></param>
        /// <param name="header"></param>
        /// <param name="ballInfo"></param>
        /// <param name="maxBalls"></param>
        /// <param name="ballCollision"></param>
        /// <param name="startButton"></param>
        /// <param name="exitButton"></param>
        public Menu(GameForm gameForm, Label header, Button startButton, ComboBox maxScore, ComboBox maxBalls, CheckBox ballCollision, Button controlButton, Button exitButton)
        {
            this.gameForm = gameForm;
            this.header = header;
            this.startButton = startButton;
            this.maxScore = maxScore;
            this.maxBalls = maxBalls;
            this.ballCollision = ballCollision;
            this.controlButton = controlButton;
            this.exitButton = exitButton;
            screenSize = gameForm.ClientSize;
            InitPositions();
            InitInfo();
        }

        /// <summary>
        /// Centers the whole menu
        /// </summary>
        private void InitPositions()
        {
            header.Location = new Point((screenSize.Width / 2) - (header.Width / 2), (int)(screenSize.Height * 0.05));
            startButton.Location = new Point((screenSize.Width / 2) - (startButton.Width / 2), (int)(screenSize.Height * 0.25));
            maxScore.Location = new Point((screenSize.Width / 2) - (maxBalls.Width / 2), (int)(screenSize.Height * 0.35));
            maxBalls.Location = new Point((screenSize.Width / 2) - (maxBalls.Width / 2), (int)(screenSize.Height * 0.45));
            ballCollision.Location = new Point((screenSize.Width / 2) - (ballCollision.Width / 2), (int)(screenSize.Height * 0.55));
            controlButton.Location = new Point((screenSize.Width / 2) - (exitButton.Width / 2), (int)(screenSize.Height * 0.65));
            exitButton.Location = new Point((screenSize.Width / 2) - (exitButton.Width / 2), (int)(screenSize.Height * 0.75));
        }

        /// <summary>
        /// Adds text to the comboBoxes
        /// </summary>
        private void InitInfo()
        {
            for (int i = 1; i <= 5; i++)
            {
                maxScore.Items.Add("First to " + i);
            }
            maxScore.SelectedIndex = 0;
            maxBalls.Items.Add("1 ball (Default)");

            for (int i = 2; i <= 4; i++)
            {
                maxBalls.Items.Add(i + " balls");
            }
            maxBalls.SelectedIndex = 0;
        }

        /// <summary>
        /// Displays simple instructions on how to move the players and bringing up the menu
        /// </summary>
        public void DisplayControls()
        {
            MessageBox.Show("When you are in a game press Esc to get up a menu!");
            MessageBox.Show("Player 1: Move up: Arrow key up. Move down: Arrow key down");
            MessageBox.Show("Player 2: Move up: 'W'. Move down: 'S'");
        }

        /// <summary>
        /// Used to hide and show the menu
        /// </summary>
        /// <param name="show"></param>
        public void ShowOrHideMenu(bool show)
        {
            if (show)
            {
                gameForm.BackColor = Color.Gray;
            }
            else
            {
                gameForm.BackColor = Color.Black;
            }
            header.Visible = show;
            startButton.Visible = show;
            maxScore.Visible = show;
            maxBalls.Visible = show;
            ballCollision.Visible = show;
            controlButton.Visible = show;
            exitButton.Visible = show;
        }

        /// <summary>
        /// returns how many points you will need to win a game
        /// </summary>
        /// <returns></returns>
        public int GetMaxScore()
        {
            return maxScore.SelectedIndex + 1;
        }

        /// <summary>
        /// Returns if ball collsion is on or not
        /// </summary>
        /// <returns></returns>
        public bool GetBallCollision()
        {
            return ballCollision.Checked;
        }

        /// <summary>
        /// Retuns how many balls that will be in the game
        /// </summary>
        /// <returns></returns>
        public int GetMaxBalls()
        {
            return maxBalls.SelectedIndex + 1;
        }
    }
}
