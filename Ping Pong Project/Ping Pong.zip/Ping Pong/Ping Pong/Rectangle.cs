﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Ping_Pong
{
    /// <summary>
    /// Daniel Petersén
    /// 2017-11-30
    /// </summary>
    class Rectangle
    {
        /// <summary>
        /// Delecering necessary instance variables
        /// </summary>
        private RectangleF rect;
        private readonly Brush brush = Brushes.Gray;
        private float speedX;
        private float speedY;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="size"></param>
        public Rectangle(Size size)
        {
            rect = new RectangleF(new Point(), size);
        }

        /// <summary>
        /// Simple set and get method
        /// </summary>
        public PointF Postion
        {
            set
            {
                rect.Location = value;
            }
            get
            {
                return rect.Location;
            }
        }

        /// <summary>
        /// Simple set method and moves the rectangle x-axis with speedX
        /// </summary>
        /// <param name="speedX"></param>
        public void MoveX(float speedX)
        {
            this.speedX = speedX;
            rect.X += speedX;
        }

        /// <summary>
        /// Simple set method and moves the rectangle y-axis with speedY
        /// </summary>
        /// <param name="speedY"></param>
        public void MoveY(float speedY)
        {
            this.speedY = speedY;
            rect.Y += speedY;
        }

        /// <summary>
        /// Returns the rectangle
        /// </summary>
        /// <returns></returns>
        public RectangleF GetRectangle()
        {
            return rect;
        }

        /// <summary>
        /// This is used to check collisions so objects dont get stuck into each other when objects move fast
        /// </summary>
        /// <returns></returns>
        public RectangleF GetNextMove()
        {
            RectangleF tempRect = new RectangleF();
            tempRect.Size = rect.Size;
            tempRect.X = rect.X + speedX;
            tempRect.Y = rect.Y + speedY;
            return tempRect;
        }

        /// <summary>
        /// Draws the rectangle with a brush
        /// </summary>
        /// <param name="g"></param>
        public void Draw(Graphics g)
        {
            g.FillRectangle(brush, rect);
        }
    }
}
