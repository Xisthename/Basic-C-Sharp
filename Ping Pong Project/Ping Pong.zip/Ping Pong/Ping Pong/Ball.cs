﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ping_Pong
{
    /// <summary>
    /// Daniel Petersén
    /// 2017-11-30
    /// </summary>
    class Ball : Rectangle
    {
        /// <summary>
        /// Delecering necessary instance variables
        /// </summary>
        private Size screenSize;
        private float speedX;
        private float speedY;
        private float maxSpeedX;
        private readonly Random random = new Random();

        /// <summary>
        /// Constructor that passes ballSize to it's superclass Rectangle
        /// Stores the screenSize into a instance variable and set's the ball postion to the spawnPoint
        /// </summary>
        /// <param name="screenSize"></param>
        /// <param name="ballSize"></param>
        /// <param name="spawnPoint"></param>
        public Ball(Size screenSize, Size ballSize, PointF spawnPoint) : base(ballSize)
        {
            this.screenSize = screenSize;
            Postion = spawnPoint;

            maxSpeedX = screenSize.Width / 120;
            speedX = (float)((screenSize.Width / 400) + (screenSize.Width / 500) * random.NextDouble());
            speedY = (float)((screenSize.Height / 300) + (screenSize.Height / 400) * random.NextDouble());

            speedX = (float)((screenSize.Width / 400) + (screenSize.Width / 500));
            speedY = (float)((screenSize.Height / 300) + (screenSize.Height / 400));

            if (random.Next(0, 2) == 0)
            {
                speedX = -speedX;
            }
            if (random.Next(0, 2) == 0)
            {
                speedY = -speedY;
            }
        }

        /// <summary>
        /// Checks after collisions with upper or bottom side of the screen
        /// </summary>
        public void CheckCollisions()
        {
            if (Postion.Y + speedY < 0)
            {
                CollisionY();
            }
            else if ((Postion.Y + GetRectangle().Height) + speedY > screenSize.Height)
            {
                CollisionY();
            }
        }

        /// <summary>
        /// When a player hits the ball the direction swaps and the speed of the ball will be increased
        /// If it collides with another ball the direction swaps and the speedX will be decreased
        /// </summary>
        /// <param name="playerHit"></param>
        public void CollisionX(bool playerHit)
        {
            if (playerHit)
            {
                if (speedX < maxSpeedX)
                {
                    speedX = 1.05F * -speedX;
                    speedY = 1.05F * speedY;
                }
                else
                {
                    speedX = -maxSpeedX;
                }
            }
            else
            {
                speedX = -0.95F * speedX;
            }
        }

        /// <summary>
        /// When the ball collides into another ball we change direction and decrease speedY
        /// This also happens when a ball collides with the top or bottom of the screen
        /// </summary>
        public void CollisionY()
        {
            speedY = -0.975F * speedY;
        }

        /// <summary>
        /// Calls upon the methods that will move the ball with speedX and speedY
        /// </summary>
        public void Move()
        {
            MoveX(speedX);
            MoveY(speedY);
        }
    }
}
