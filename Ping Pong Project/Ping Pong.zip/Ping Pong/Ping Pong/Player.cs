﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ping_Pong
{
    /// <summary>
    /// Daniel Petersén
    /// 2017-11-30
    /// </summary>
    class Player : Rectangle
    {
        /// <summary>
        /// Delecering necessary instance variables
        /// </summary>
        private Size screenSize;
        private Label scoreLabel;
        private int score;
        private float speed;
        private bool moveUp = false;
        private bool moveDown = false;

        /// <summary>
        /// Constructor that passes playerSize to it's superclass Rectangle
        /// Stores the screenSize and scoreLabel inside of this class into instance variables
        /// </summary>
        /// <param name="screenSize"></param>
        /// <param name="playerSize"></param>
        /// <param name="scoreLabel"></param>
        public Player(Size screenSize, Size playerSize, Label scoreLabel) : base(playerSize)
        {
            this.screenSize = screenSize;
            this.scoreLabel = scoreLabel;
            speed = screenSize.Height / 50;
        }

        /// <summary>
        /// Used to show or hide the scoreLabel
        /// </summary>
        /// <param name="show"></param>
        public void ShowScoreLabel(bool show)
        {
            scoreLabel.Visible = show;
        }

        /// <summary>
        /// Simple set method that also updates the scoreLabel's text to the current score
        /// </summary>
        public void Scored()
        {
            score++;
            scoreLabel.Text = score.ToString();
        }

        /// <summary>
        /// Simpel set and get method
        /// </summary>
        public int Score
        {
            set
            {
                score = value;
                scoreLabel.Text = score.ToString();
            }
            get
            {
                return score;
            }
        }

        /// <summary>
        /// Simple set method
        /// </summary>
        /// <param name="moveUp"></param>
        public void SetMoveUp(bool moveUp)
        {
            this.moveUp = moveUp;
        }

        /// <summary>
        /// Simple set method
        /// </summary>
        /// <param name="moveDown"></param>
        public void SetMoveDown(bool moveDown)
        {
            this.moveDown = moveDown;
        }

        /// <summary>
        /// Checks if the player shall move up or down and also checks so that the player cannot move outside the screen
        /// </summary>
        public void Move()
        {
            if (moveUp)
            {
                if (Postion.Y > 0)
                {
                    MoveY(-speed);
                }
            }
            else if (moveDown)
            {
                if ((Postion.Y + GetRectangle().Height) < screenSize.Height)
                {
                    MoveY(speed);
                }
            }
        }
    }
}
