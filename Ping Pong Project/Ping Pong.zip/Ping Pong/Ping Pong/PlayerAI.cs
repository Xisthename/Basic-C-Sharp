﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ping_Pong
{
    class PlayerAI : Player
    {
        public PlayerAI(Size screenSize, Size playerSize, Label scoreLabel) : base(screenSize, playerSize, scoreLabel)
        {

        }
    }
}
