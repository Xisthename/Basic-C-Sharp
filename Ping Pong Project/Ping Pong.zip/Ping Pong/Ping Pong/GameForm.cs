﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ping_Pong
{
    /// <summary>
    /// Daniel Petersén
    /// 2017-11-30
    /// </summary>
    public partial class GameForm : Form
    {
        /// <summary>
        /// Delecering necessary instance variables
        /// </summary>
        private Menu menu;
        private GameController gameController;

        public GameForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// When the program starts we go into fullscreen and starts a new game
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GameForm_Shown(object sender, EventArgs e)
        {
            DoubleBuffered = true;
            FullscreenMode();
            menu = new Menu(this, header, startButton, maxScore, maxBalls, ballCollision, controlButton, exitButton);
            gameController = new GameController(this, updateTimer, countdownTimer, inGameResume, inGameMenu, inGameExit, scoreLabel1, ScoreLabel2);
        }

        /// <summary>
        /// Sets the window to fullscreen
        /// </summary>
        private void FullscreenMode()
        {
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
        }

        /// <summary>
        /// Starts the game
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void startButton_Click(object sender, EventArgs e)
        {
            menu.ShowOrHideMenu(false);
            gameController.StartNewGame(menu.GetMaxScore(), menu.GetMaxBalls(), menu.GetBallCollision());
        }

        /// <summary>
        /// Gives simple instructions on how to move the players
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void controlButton_Click(object sender, EventArgs e)
        {
            menu.DisplayControls();
        }

        /// <summary>
        /// Takes in a bool show that decides the following 
        /// 1. Shows the menu and stops the game 
        /// 2. Hides the menu
        /// </summary>
        /// <param name="show"></param>
        public void ShowOrHideInGameMenu(bool show)
        {
            if (show)
            {
                inGameResume.Show();
                inGameMenu.Show();
                inGameExit.Show();
                gameController.PauseGame();
                Cursor.Show();
            }
            else
            {
                inGameResume.Hide();
                inGameMenu.Hide();
                inGameExit.Hide();
            }
        }

        /// <summary>
        /// When the resumeButton is pressed we call upon the method ShowInGameMenu
        /// Which will resume the game and hide controls from the user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void inGameResume_Click(object sender, EventArgs e)
        {
            gameController.ResumeGame();
            ShowOrHideInGameMenu(false);
            Cursor.Hide();
            Focus();
        }

        /// <summary>
        /// Exits the current game and brings up the main menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void inGameMenu_Click(object sender, EventArgs e)
        {
            BackToMenu();
        }

        /// <summary>
        /// Exit the current game and brings back the main menu
        /// </summary>
        public void BackToMenu()
        {
            gameController.ExitGame();
            ShowOrHideInGameMenu(false);
            menu.ShowOrHideMenu(true);
        }

        /// <summary>
        ///  When the inGameExit is pressed the program will be shut down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void inGameExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        ///  When the exitButton is pressed the program will be shut down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// (When a key is hold down this event will be triggerd)
        /// Handle key events such as when the user presses the esc button the menu will be shown
        /// It passes the other key events to the method MoveLogic which will determine if a user is holding down the keys to move
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GameForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (gameController != null)
            {
                if (e.KeyData == Keys.Escape)
                {
                    if (gameController.InGame)
                    {
                        ShowOrHideInGameMenu(true);
                    }
                }
                else
                {
                    gameController.MoveLogic(true, e);
                }
            }
        }

        /// <summary>
        /// (When a key is released this event will be triggerd)
        /// Passes the inforamtion to the method MoveLogic which will determine if a user should stop moving 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GameForm_KeyUp(object sender, KeyEventArgs e)
        {
            if (gameController != null)
            {
                gameController.MoveLogic(false, e);
            }
        }
        
        /// <summary>
        /// (While we are in the game)
        /// Every 3 ms we move the players, check after collisions and updates the screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void updateTimer_Tick(object sender, EventArgs e)
        {
            if (gameController != null)
            {
                if (gameController.InGame)
                {
                    gameController.MovePlayers();
                    gameController.CheckCollisions();
                }
                else
                {
                    updateTimer.Stop();
                }
                Invalidate();
            }
        }

        /// <summary>
        /// Draws the players and the ball(s) while in the game
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GameForm_Paint(object sender, PaintEventArgs e)
        {
            if (gameController != null)
            {
                if (gameController.InGame)
                {
                    Graphics g = e.Graphics;
                    gameController.Draw(g);
                }
            }
        }

        /// <summary>
        /// Calls upon a method that counts down to the next ball
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void countdownTimer_Tick(object sender, EventArgs e)
        {
            if (gameController != null)
            {
                gameController.CountDownTime(countdownTimer.Interval);
            }
        }
    }
}
