﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ping_Pong
{
    /// <summary>
    /// Daniel Petersén
    /// 2017-11-30
    /// </summary>
    class GameController
    {
        /// <summary>
        /// Delecering necessary instance variables
        /// </summary>
        private int maxScore;
        private int maxBalls;
        private bool ballCollision;
        private float countDownTime;
        private int spawnBallTime = 10000;
        private bool inGame;
        private GameForm gameForm;
        private Size screenSize;
        private Timer updateTimer;
        private Timer countDownTimer;
        private Player player1;
        private Player player2;
        private List<Ball> ballList = new List<Ball>();
        private Size playerSize;
        private Size ballSize;

        /// <summary>
        /// Constructor that takes in necessary objects
        /// Delcares the scrrenSize and uses it to place the objects so that the game can be played on any screen
        /// </summary>
        /// <param name="gameForm"></param>
        /// <param name="updateTimer"></param>
        /// <param name="countDownTimer"></param>
        /// <param name="resumeButton"></param>
        /// <param name="menuButton"></param>
        /// <param name="exitButton"></param>
        /// <param name="scoreLabel1"></param>
        /// <param name="scoreLabel2"></param>
        public GameController(GameForm gameForm, Timer updateTimer, Timer countDownTimer, Button resumeButton, Button menuButton, 
                              Button exitButton, Label scoreLabel1, Label scoreLabel2)
        {
            this.gameForm = gameForm;
            this.updateTimer = updateTimer;
            this.countDownTimer = countDownTimer;
            screenSize = gameForm.ClientSize;
            playerSize = new Size((int)(screenSize.Width * 0.01), (int)(screenSize.Height * 0.25));
            ballSize = new Size((int)(screenSize.Width * 0.02), (int)(screenSize.Width * 0.02));

            resumeButton.Location = new Point((screenSize.Width / 2) - (resumeButton.Width / 2), (int)(screenSize.Height * 0.20));
            menuButton.Location = new Point((screenSize.Width / 2) - (menuButton.Width / 2), (int)(screenSize.Height * 0.4));
            exitButton.Location = new Point((screenSize.Width / 2) - (exitButton.Width / 2), (int)(screenSize.Height * 0.6));

            scoreLabel1.Location = new Point((screenSize.Width / 2) + (int)(screenSize.Width * 0.10) - (scoreLabel1.Width / 2), 0);
            scoreLabel2.Location = new Point((screenSize.Width / 2) - (int)(screenSize.Width * 0.10 + (scoreLabel2.Width / 2)), 0);
            player1 = new Player(screenSize, playerSize, scoreLabel1);
            player2 = new Player(screenSize, playerSize, scoreLabel2);
        }

        /// <summary>
        /// Starting a new game means clearing old scores, moving the players, start the updateTimer
        /// And creating a new ball to play with
        /// </summary>
        public void StartNewGame(int maxScore, int maxBalls, bool ballCollision)
        {
            this.maxScore = maxScore;
            this.maxBalls = maxBalls;
            this.ballCollision = ballCollision;
            player1.Score = 0;
            player2.Score = 0;
            player1.SetMoveUp(false);
            player1.SetMoveDown(false);
            player2.SetMoveUp(false);
            player2.SetMoveDown(false);
            player1.ShowScoreLabel(true);
            player2.ShowScoreLabel(true);
            ResetGame();
            inGame = true;
            gameForm.Focus();
            Cursor.Hide();
        }

        /// <summary>
        /// Moves the players, removes the ball(s), starts the updateTimer and creats a new play to play with
        /// </summary>
        private void ResetGame()
        {
            player1.Postion = new PointF(screenSize.Width - playerSize.Width, (screenSize.Height / 2) - (playerSize.Height / 2));
            player2.Postion = new PointF(0, (screenSize.Height / 2) - (playerSize.Height / 2));
            RemoveBalls();
            updateTimer.Start();
            CreateNewBall();
        }

        /// <summary>
        /// Removes all ball(s)
        /// </summary>
        private void RemoveBalls()
        {
            if (ballList.Count > 0)
            {
                for (int i = 0; i < ballList.Count; i++)
                {
                    ballList[i] = null;
                }
                ballList.Clear();
            }
        }

        /// <summary>
        /// Creates a new ball, adds it to the ballList and checks if a new ball should be created in the near future
        /// </summary>
        public void CreateNewBall()
        {
            Ball ball = new Ball(screenSize, ballSize, new PointF((screenSize.Width / 2) - (ballSize.Width / 2), (screenSize.Height / 2) - (ballSize.Height / 2)));
            ballList.Add(ball);

            if (ballList.Count < maxBalls)
            { 
                Random random = new Random();
                countDownTime = random.Next(spawnBallTime, (int)(spawnBallTime + spawnBallTime * 0.5));
                countDownTimer.Start();
            }
        }

        /// <summary>
        /// If the countDownTime is greater than zero we subtract time from it
        /// When the countDownTime is less or equal to zero we stop the countDownTimer and call upon a method that will create a new ball
        /// </summary>
        /// <param name="time"></param>
        public void CountDownTime(float time)
        {
            if (countDownTime > 0)
            {
                countDownTime -= time;
            }
            else
            {
                countDownTimer.Stop();
                CreateNewBall();
            }
        }

        /// <summary>
        /// Stops our timers which updates the game
        /// </summary>
        public void PauseGame()
        {
            updateTimer.Stop();
            countDownTimer.Stop();
        }

        /// <summary>
        /// Starts our timers again which updates the game
        /// </summary>
        public void ResumeGame()
        {
            if (ballList.Count < maxBalls)
            {
                countDownTimer.Start();
            }
            updateTimer.Start();
        }

        /// <summary>
        /// Exits the current game
        /// </summary>
        public void ExitGame()
        {
            player1.ShowScoreLabel(false);
            player2.ShowScoreLabel(false);
            RemoveBalls();
            updateTimer.Start();
            inGame = false;
        }

        /// <summary>
        /// Simple set and get method
        /// </summary>
        /// <returns></returns>
        public bool InGame
        {
            set
            {
                inGame = value;
            }
            get
            {
                return inGame;
            }
        }

        /// <summary>
        /// Takes in if the user is holding down a key or have released a key
        /// Takes in the key event which is used to determine which key that was either hold down or released
        /// If the key was arrow key up or arrow key down or W or S we pass on the information to their methods
        /// that sets booleans in oder to know if the player should move up or down or stop moving
        /// </summary>
        /// <param name="keyDown"></param>
        /// <param name="e"></param>
        public void MoveLogic(bool keyDown, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up)
            {
                player1.SetMoveUp(keyDown);
            }
            if (e.KeyData == Keys.Down)
            {
                player1.SetMoveDown(keyDown);
            }

            if (e.KeyData == Keys.W)
            {
                player2.SetMoveUp(keyDown);
            }
            if (e.KeyData == Keys.S)
            {
                player2.SetMoveDown(keyDown);
            }
        }

        /// <summary>
        /// If the player objects is not null we call upon the move method which will move the players
        /// </summary>
        public void MovePlayers()
        {
            if (player1 != null)
            {
                player1.Move();
            }
            if (player2 != null)
            {
                player2.Move();
            }
        }

        /// <summary>
        /// Checks if any balls collides into another ball
        /// Checks if any ball collides into left or right side of the screen
        /// Checks if any balls collides into a player
        /// Calls upon a method within the ball which checks collisions into the upper or bottom side of the screen
        /// Lastly we move all the balls
        /// 
        /// I know that the collision between balls is far from perfect!
        /// It can be seen when two balls travel at the same direction and collides
        /// They can even sometimes get stuck togheter due to it's not an elastic collision
        /// I have prevented it from happening a lot with predicting the next move of the balls
        /// That's why i added so it can be turned of from the menu
        /// </summary>
        public void CheckCollisions()
        {
            for (int x = 0; x < ballList.Count; x++)
            {
                if (ballList[x] != null)
                {
                    if (ballCollision) {
                        for (int y = 0; y < ballList.Count; y++)
                        {
                            if (ballList[y] != null && x != y)
                            {
                                if (ballList[x].GetNextMove().IntersectsWith(ballList[y].GetNextMove()))
                                {
                                    ballList[x].CollisionX(false);
                                    ballList[x].CollisionY();

                                    ballList[y].CollisionX(false);
                                    ballList[y].CollisionY();
                                }
                            }
                        }
                    }
                    ballList[x].Move();

                    if (ballList[x].Postion.X > screenSize.Width - ballList[x].GetRectangle().Width)
                    {
                        Scoring(false);
                    }
                    else if (ballList[x].Postion.X < 0)
                    {
                        Scoring(true);
                    }
                    else if (ballList[x].GetNextMove().IntersectsWith(player1.GetNextMove()))
                    {
                        ballList[x].CollisionX(true);
                    }
                    else if (ballList[x].GetNextMove().IntersectsWith(player2.GetNextMove()))
                    {
                        ballList[x].CollisionX(true);
                    }
                    else
                    {
                        ballList[x].CheckCollisions();
                    }
                }
            }
        }

        /// <summary>
        /// Updates the score of a player and resets the player and the balls
        /// </summary>
        /// <param name="player1Scored"></param>
        private void Scoring(bool player1Scored)
        {
            ResetGame();

            if (player1Scored)
            {
                player1.Scored();
                if (player1.Score == maxScore)
                {
                    Cursor.Show();
                    gameForm.BackToMenu();
                    MessageBox.Show("Player 1 Won with the score " + player1.Score + " to " + player2.Score);
                }
            }
            else
            {
                player2.Scored();
                if (player2.Score == maxScore)
                {
                    Cursor.Show();
                    gameForm.BackToMenu();
                    MessageBox.Show("Player 2 Won with the score " + player2.Score + " to " + player1.Score);
                }
            }
        }

        /// <summary>
        /// If an object is not null we call upon methods that will draw it on the screen
        /// </summary>
        /// <param name="g"></param>
        public void Draw(Graphics g)
        {
            if (player1 != null)
            {
                player1.Draw(g);
            }
            if (player2 != null)
            {
                player2.Draw(g);
            }
            foreach (Ball ball in ballList)
            {
                if (ball != null)
                {
                    ball.Draw(g);
                }
            }
        }
    }
}
